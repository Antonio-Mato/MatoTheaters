// Android emulator: http://10.0.2.2:3000/api
// iOS simulator:     http://localhost:3000/api
// Physical phone:    "http://192.168.1.9:3000/api"
export const API_BASE_URL = "http://192.168.1.9:3000/api"; 
