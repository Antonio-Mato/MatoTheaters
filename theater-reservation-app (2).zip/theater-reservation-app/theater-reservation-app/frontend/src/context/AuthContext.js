import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import * as SecureStore from 'expo-secure-store';
import { apiRequest, setAuthToken } from '../api/client';

const TOKEN_KEY = 'theatre_reservation_token';
const USER_KEY = 'theatre_reservation_user';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(null);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function restoreSession() {
      try {
        const storedToken = await SecureStore.getItemAsync(TOKEN_KEY);
        const storedUser = await SecureStore.getItemAsync(USER_KEY);

        if (storedToken) {
          setAuthToken(storedToken);
          setToken(storedToken);
        }

        if (storedUser) {
          setUser(JSON.parse(storedUser));
        }
      } finally {
        setIsLoading(false);
      }
    }

    restoreSession();
  }, []);

  async function saveSession(authResult) {
    setAuthToken(authResult.token);
    setToken(authResult.token);
    setUser(authResult.user);
    await SecureStore.setItemAsync(TOKEN_KEY, authResult.token);
    await SecureStore.setItemAsync(USER_KEY, JSON.stringify(authResult.user));
  }

  async function login(email, password) {
    const result = await apiRequest('/login', {
      method: 'POST',
      body: { email, password }
    });
    await saveSession(result);
  }

  async function register(name, email, password) {
    const result = await apiRequest('/register', {
      method: 'POST',
      body: { name, email, password }
    });
    await saveSession(result);
  }

  async function logout() {
    setAuthToken(null);
    setToken(null);
    setUser(null);
    await SecureStore.deleteItemAsync(TOKEN_KEY);
    await SecureStore.deleteItemAsync(USER_KEY);
  }

  const value = useMemo(() => ({
    token,
    user,
    isLoading,
    isAuthenticated: Boolean(token),
    login,
    register,
    logout
  }), [token, user, isLoading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return context;
}
