export const colors = {
  background: '#F3F4F6',
  surface: '#FFFFFF',
  primary: '#7C3AED',
  primaryDark: '#5B21B6',
  text: '#111827',
  muted: '#6B7280',
  border: '#E5E7EB',
  danger: '#DC2626',
  success: '#059669',
  warning: '#D97706',
  disabled: '#D1D5DB'
};

export const spacing = {
  xs: 6,
  sm: 10,
  md: 16,
  lg: 24,
  xl: 32
};
