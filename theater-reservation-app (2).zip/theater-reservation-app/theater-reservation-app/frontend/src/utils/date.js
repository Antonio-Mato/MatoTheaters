export function formatDateTime(value) {
  if (!value) return 'Not scheduled';
  const date = new Date(value);
  return date.toLocaleString(undefined, {
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit'
  });
}

export function formatMoney(value) {
  const number = Number(value || 0);
  return `€${number.toFixed(2)}`;
}
