import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  View
} from 'react-native';
import { apiRequest } from '../api/client';
import Loading from '../components/Loading';
import { formatMoney } from '../utils/date';

const R = '#B00020';
const B = '#050505';

export default function ReservationScreen({ route, navigation }) {
  const { showtimeId, showTitle } = route.params;

  const [showtime, setShowtime] = useState(null);
  const [seats, setSeats] = useState([]);
  const [selectedSeatIds, setSelectedSeatIds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const loadSeats = useCallback(async () => {
    try {
      setLoading(true);
      const data = await apiRequest(`/seats?showtimeId=${showtimeId}`);
      setShowtime(data.showtime);
      setSeats(data.seats || []);
      setSelectedSeatIds([]);
    } catch (error) {
      Alert.alert('Could not load seats', error.message);
    } finally {
      setLoading(false);
    }
  }, [showtimeId]);

  useEffect(() => {
    loadSeats();
  }, [loadSeats]);

  const total = useMemo(() => {
    return seats
      .filter((seat) => selectedSeatIds.includes(seat.seat_id))
      .reduce((sum, seat) => sum + Number(seat.final_price), 0);
  }, [seats, selectedSeatIds]);

  function toggleSeat(seat) {
    if (!seat.is_available) return;

    setSelectedSeatIds((current) =>
      current.includes(seat.seat_id)
        ? current.filter((id) => id !== seat.seat_id)
        : [...current, seat.seat_id]
    );
  }

  async function submitReservation() {
    if (selectedSeatIds.length === 0) {
      Alert.alert('No seats selected', 'Please choose at least one seat.');
      return;
    }

    try {
      setSubmitting(true);

      const data = await apiRequest('/reservations', {
        method: 'POST',
        body: {
          showtimeId,
          seatIds: selectedSeatIds
        }
      });

      Alert.alert(
        'Reservation confirmed',
        `Reservation #${data.reservation.reservation_id} created successfully.`,
        [
          { text: 'My Tickets', onPress: () => navigation.navigate('Profile') },
          { text: 'Shows', onPress: () => navigation.navigate('Home') }
        ]
      );
    } catch (error) {
      Alert.alert('Reservation failed', error.message);
      await loadSeats();
    } finally {
      setSubmitting(false);
    }
  }

  function Seat({ item }) {
    const selected = selectedSeatIds.includes(item.seat_id);

    return (
      <Pressable
        onPress={() => toggleSeat(item)}
        style={[
          styles.seat,
          item.is_available ? styles.available : styles.reserved,
          selected && styles.selected
        ]}
      >
        <Text style={[styles.seatText, selected && styles.selectedText]}>
          {item.row_label}{item.seat_number}
        </Text>

        <Text style={[styles.priceText, selected && styles.selectedText]}>
          {formatMoney(item.final_price)}
        </Text>
      </Pressable>
    );
  }

  function Header() {
    return (
      <>
        <View style={styles.hero}>
          <Pressable style={styles.backBtn} onPress={() => navigation.navigate('ShowDetails', { showId: showtime?.show_id })}>
            <Text style={styles.btnText}>← Back</Text>
          </Pressable>

          <Text style={styles.brand}>Mato's Theaters</Text>
          <Text style={styles.title}>{showTitle || showtime?.show_title}</Text>
          <Text style={styles.meta}>🏛 {showtime?.hall_name}</Text>
          <Text style={styles.helper}>Choose your seats for tonight’s performance.</Text>
        </View>

        <View style={styles.legend}>
          <View style={styles.legendItem}>
            <View style={[styles.dot, styles.available]} />
            <Text style={styles.legendText}>Available</Text>
          </View>

          <View style={styles.legendItem}>
            <View style={[styles.dot, styles.selected]} />
            <Text style={styles.legendText}>Selected</Text>
          </View>

          <View style={styles.legendItem}>
            <View style={[styles.dot, styles.reserved]} />
            <Text style={styles.legendText}>Reserved</Text>
          </View>
        </View>

        <View style={styles.stage}>
          <Text style={styles.stageText}>STAGE</Text>
        </View>
      </>
    );
  }

  if (loading) {
    return <Loading message="Loading seat map..." />;
  }

  return (
    <View style={styles.page}>
      <FlatList
        data={seats}
        keyExtractor={(item) => String(item.seat_id)}
        renderItem={Seat}
        numColumns={4}
        ListHeaderComponent={Header}
        contentContainerStyle={styles.list}
      />

      <View style={styles.summary}>
        <View>
          <Text style={styles.summarySmall}>Selected seats</Text>
          <Text style={styles.summaryBig}>{selectedSeatIds.length}</Text>
        </View>

        <View>
          <Text style={styles.summarySmall}>Total</Text>
          <Text style={styles.total}>{formatMoney(total)}</Text>
        </View>

        <Pressable style={styles.confirmBtn} onPress={submitReservation} disabled={submitting}>
          {submitting ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.btnText}>Confirm</Text>
          )}
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: R
  },

  list: {
    padding: 16,
    paddingBottom: 125
  },

  hero: {
    backgroundColor: B,
    borderRadius: 24,
    padding: 24,
    marginBottom: 14
  },

  backBtn: {
    alignSelf: 'flex-start',
    backgroundColor: R,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 30,
    marginBottom: 18
  },

  brand: {
    color: '#ffb3b3',
    fontSize: 14,
    fontWeight: '900',
    letterSpacing: 2,
    textTransform: 'uppercase'
  },

  title: {
    color: '#fff',
    fontSize: 31,
    fontWeight: '900',
    marginTop: 8
  },

  meta: {
    color: '#eee',
    fontWeight: '800',
    marginTop: 8
  },

  helper: {
    color: '#ccc',
    fontSize: 15,
    lineHeight: 22,
    marginTop: 10
  },

  legend: {
    backgroundColor: '#fff',
    borderRadius: 18,
    padding: 14,
    marginBottom: 14,
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 8
  },

  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6
  },

dot: {
  width: 16,
  height: 16,
  borderRadius: 5,
  borderWidth: 2,
  borderColor: B
},

  legendText: {
    color: B,
    fontWeight: '800',
    fontSize: 12
  },

  stage: {
    backgroundColor: B,
    borderRadius: 50,
    paddingVertical: 13,
    marginBottom: 16,
    alignItems: 'center'
  },

  stageText: {
    color: '#fff',
    fontWeight: '900',
    letterSpacing: 5
  },

  seat: {
    flex: 1,
    minWidth: '22%',
    margin: 6,
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 2
  },

  available: {
    backgroundColor: '#fff',
    borderColor: 'black'
  },

  reserved: {
    backgroundColor: '#777',
    borderColor: '#777',
    opacity: 0.7
  },

  selected: {
    backgroundColor: B,
    borderColor: B
  },

  seatText: {
    color: B,
    fontWeight: '900',
    marginBottom: 4
  },

  priceText: {
    color: '#555',
    fontSize: 12,
    fontWeight: '800'
  },

  selectedText: {
    color: '#fff'
  },

  summary: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 16,
    backgroundColor: '#fff',
    borderRadius: 24,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 2,
    borderColor: B
  },

  summarySmall: {
    color: '#555',
    fontSize: 12,
    fontWeight: '900',
    textTransform: 'uppercase'
  },

  summaryBig: {
    color: B,
    fontSize: 22,
    fontWeight: '900'
  },

  total: {
    color: R,
    fontSize: 22,
    fontWeight: '900'
  },

  confirmBtn: {
    backgroundColor: B,
    paddingVertical: 14,
    paddingHorizontal: 22,
    borderRadius: 18,
    minWidth: 105,
    alignItems: 'center'
  },

  btnText: {
    color: '#fff',
    fontWeight: '900'
  }
});