import React, { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  View
} from 'react-native';
import { apiRequest } from '../api/client';
import { useAuth } from '../context/AuthContext';
import { formatDateTime, formatMoney } from '../utils/date';

const R = '#B00020';
const B = '#050505';

export default function ProfileScreen({ navigation }) {
  const { user, logout } = useAuth();
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [canceling, setCanceling] = useState(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      const data = await apiRequest('/user/reservations');
      setTickets(data.reservations || []);
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function refresh() {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  }

  async function cancelTicket(id) {
    try {
      setCanceling(id);
      await apiRequest(`/reservations/${id}`, { method: 'DELETE' });
      await load();
      Alert.alert('Cancelled', 'Reservation cancelled successfully.');
    } catch (e) {
      Alert.alert('Cancel failed', e.message);
    } finally {
      setCanceling(null);
    }
  }

  function Header() {
    return (
      <>
        <View style={styles.hero}>
          <Text style={styles.brand}>Mato's Theaters</Text>
          <Text style={styles.title}>My Tickets</Text>
          <Text style={styles.name}>{user?.name || 'Guest'}</Text>
          <Text style={styles.email}>{user?.email}</Text>

          <View style={styles.actions}>
            <Pressable style={styles.redBtn} onPress={() => navigation.navigate('Home')}>
              <Text style={styles.btnText}>Browse Shows</Text>
            </Pressable>

            <Pressable style={styles.blackBtn} onPress={logout}>
              <Text style={styles.btnText}>Logout</Text>
            </Pressable>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Reservations</Text>
      </>
    );
  }

  function Ticket({ item }) {
    const status = String(item.status || '').toUpperCase();
    const active = status === 'CONFIRMED';
    const future = item.starts_at ? new Date(item.starts_at).getTime() > Date.now() : false;
    const canCancel = active && future;

    return (
      <View style={styles.ticket}>
        <View style={styles.ticketHeader}>
          <Text style={styles.show}>{item.show_title}</Text>
          <Text style={[styles.badge, !active && styles.badgeOff]}>
            {item.status || 'CONFIRMED'}
          </Text>
        </View>

        <Text style={styles.red}>🎭 {item.theatre_name}</Text>
        <Text style={styles.muted}>📍 {item.theatre_location}</Text>

        <View style={styles.divider} />

        <Text style={styles.info}>🕒 {formatDateTime(item.starts_at)}</Text>
        <Text style={styles.info}>🏛 {item.hall_name}</Text>
        <Text style={styles.info}>💺 Seats: {item.seats || '-'}</Text>

        <View style={styles.bottom}>
          <View>
            <Text style={styles.label}>Total</Text>
            <Text style={styles.total}>{formatMoney(item.total_price)}</Text>
          </View>

          {canCancel && (
            <Pressable
              style={styles.cancelBtn}
              onPress={() => cancelTicket(item.reservation_id)}
              disabled={canceling === item.reservation_id}
            >
              {canceling === item.reservation_id ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.btnText}>Cancel</Text>
              )}
            </Pressable>
          )}
        </View>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color="#fff" size="large" />
        <Text style={styles.loadingText}>Loading your tickets...</Text>
      </View>
    );
  }

  return (
    <View style={styles.page}>
      <FlatList
        data={tickets}
        keyExtractor={(x) => String(x.reservation_id)}
        renderItem={Ticket}
        ListHeaderComponent={Header}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} />}
        contentContainerStyle={styles.list}
        ListEmptyComponent={<Text style={styles.empty}>No reservations yet.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: R
  },

  list: {
    padding: 16,
    paddingBottom: 30
  },

  center: {
    flex: 1,
    backgroundColor: R,
    justifyContent: 'center',
    alignItems: 'center'
  },

  loadingText: {
    color: '#fff',
    marginTop: 12,
    fontWeight: '900'
  },

  hero: {
    backgroundColor: B,
    borderRadius: 24,
    padding: 24,
    marginBottom: 18
  },

  brand: {
    color: '#ffb3b3',
    fontSize: 14,
    fontWeight: '900',
    letterSpacing: 2,
    textTransform: 'uppercase'
  },

  title: {
    color: '#fff',
    fontSize: 36,
    fontWeight: '900',
    marginTop: 8
  },

  name: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '900',
    marginTop: 12
  },

  email: {
    color: '#ccc',
    marginTop: 4,
    fontWeight: '700'
  },

  actions: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 20
  },

  redBtn: {
    flex: 1,
    backgroundColor: R,
    padding: 14,
    borderRadius: 30,
    alignItems: 'center'
  },

  blackBtn: {
    flex: 1,
    backgroundColor: '#222',
    padding: 14,
    borderRadius: 30,
    alignItems: 'center'
  },

  sectionTitle: {
    color: '#fff',
    fontSize: 26,
    fontWeight: '900',
    marginBottom: 12
  },

  ticket: {
    backgroundColor: '#fff',
    borderRadius: 24,
    padding: 18,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: B,
    borderLeftWidth: 8
  },

  ticketHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
    alignItems: 'flex-start'
  },

  show: {
    flex: 1,
    color: B,
    fontSize: 24,
    fontWeight: '900'
  },

  badge: {
    backgroundColor: R,
    color: '#fff',
    fontWeight: '900',
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 20,
    overflow: 'hidden'
  },

  badgeOff: {
    backgroundColor: '#777'
  },

  red: {
    color: R,
    fontWeight: '900',
    marginTop: 10
  },

  muted: {
    color: '#555',
    fontWeight: '700',
    marginTop: 4
  },

  divider: {
    height: 1,
    backgroundColor: '#ddd',
    marginVertical: 14
  },

  info: {
    color: '#333',
    fontWeight: '800',
    marginTop: 7
  },

  bottom: {
    marginTop: 18,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 14
  },

  label: {
    color: '#666',
    fontSize: 12,
    fontWeight: '900',
    textTransform: 'uppercase'
  },

  total: {
    color: R,
    fontSize: 23,
    fontWeight: '900',
    marginTop: 2
  },

  cancelBtn: {
    backgroundColor: B,
    paddingVertical: 13,
    paddingHorizontal: 24,
    borderRadius: 16,
    minWidth: 105,
    alignItems: 'center'
  },

  btnText: {
    color: '#fff',
    fontWeight: '900'
  },

  empty: {
    color: '#fff',
    textAlign: 'center',
    marginTop: 35,
    fontSize: 16,
    fontWeight: '900'
  }
});