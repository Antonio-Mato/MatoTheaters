import React, { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  ImageBackground,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View
} from 'react-native';
import { apiRequest } from '../api/client';
import { useAuth } from '../context/AuthContext';
import { formatDateTime, formatMoney } from '../utils/date';

const R = '#B00020';
const B = '#050505';

const SHOW_IMAGES = {
  1: require('../../assets/show-1.jpg'),
  2: require('../../assets/show-2.png'),
  3: require('../../assets/show-3.png'),
  4: require('../../assets/show-4.png')
};

export default function HomeScreen({ navigation }) {
  const { width } = useWindowDimensions();
  const heroHeight = Math.min(Math.max((width - 32) * 9 / 16, 250), 480);

  const { user, logout } = useAuth();
  const [shows, setShows] = useState([]);
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      setBusy(true);
      const query = q.trim() ? `?q=${encodeURIComponent(q.trim())}` : '';
      const data = await apiRequest(`/shows${query}`);
      setShows(data.shows || []);
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setBusy(false);
    }
  }, [q]);

  useEffect(() => {
    load();
  }, []);

  async function refresh() {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  }

  function Header() {
    return (
      <>
        <ImageBackground
          source={require('../../assets/hero.png')}
          resizeMode="cover"
          style={[styles.hero, { height: heroHeight }]}
          imageStyle={styles.heroImage}
        >
          <View style={styles.heroOverlay}>
            <Text style={styles.brand}>Mato's Theaters</Text>
            <Text style={styles.heroTitle}>Tonight’s Stage Awaits</Text>
            <Text style={styles.heroText}>
              Welcome, {user?.name || 'Guest'}. Discover shows, reserve seats,
              and enjoy the spotlight.
            </Text>

            <View style={styles.heroBtns}>
              <Pressable style={styles.redBtn} onPress={() => navigation.navigate('Profile')}>
                <Text style={styles.btnText}>My Tickets</Text>
              </Pressable>

              <Pressable style={styles.blackBtn} onPress={logout}>
                <Text style={styles.btnText}>Logout</Text>
              </Pressable>
            </View>
          </View>
        </ImageBackground>

        <View style={styles.search}>
          <TextInput
            style={styles.input}
            placeholder="Search shows, theatres, locations..."
            placeholderTextColor="#888"
            value={q}
            onChangeText={setQ}
            onSubmitEditing={load}
          />

          <Pressable style={styles.searchBtn} onPress={load}>
            {busy ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnText}>Search</Text>}
          </Pressable>
        </View>

        <Text style={styles.sectionTitle}>Now Showing</Text>
      </>
    );
  }

  function ShowCard({ item }) {
    return (
      <Pressable
        style={styles.card}
        onPress={() => navigation.navigate('ShowDetails', { showId: item.show_id })}
      >
        <ImageBackground
          source={SHOW_IMAGES[item.show_id]}
          resizeMode="cover"
          style={styles.showImage}
          imageStyle={styles.showImageStyle}
        >
          <View style={styles.showOverlay}>
            <Text style={styles.showTitle}>{item.title}</Text>
            <Text style={styles.age}>{item.age_rating || 'ALL'}</Text>
          </View>
        </ImageBackground>

        <View style={styles.body}>
          <Text style={styles.red}>🎭 {item.theatre_name}</Text>
          <Text style={styles.muted}>📍 {item.theatre_location}</Text>
          <Text style={styles.desc} numberOfLines={3}>{item.description}</Text>

          <View style={styles.row}>
            <Text style={styles.time}>
              {item.next_showtime ? formatDateTime(item.next_showtime) : 'No upcoming showtime'}
            </Text>
            <Text style={styles.price}>{formatMoney(item.starting_price)}</Text>
          </View>
        </View>
      </Pressable>
    );
  }

  return (
    <View style={styles.page}>
      <FlatList
        data={shows}
        keyExtractor={(x) => String(x.show_id)}
        renderItem={ShowCard}
        ListHeaderComponent={Header}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} />}
        contentContainerStyle={styles.list}
        ListEmptyComponent={!busy && <Text style={styles.empty}>No shows found.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: R
  },

  list: {
    padding: 16,
    paddingBottom: 28
  },

  hero: {
    width: '100%',
    borderRadius: 24,
    overflow: 'hidden',
    marginBottom: 14,
    backgroundColor: B
  },

  heroImage: {
    width: '100%',
    height: '100%',
    borderRadius: 24
  },

  heroOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
    padding: 24,
    backgroundColor: 'rgba(0,0,0,0.45)'
  },

  brand: {
    color: '#ffb3b3',
    fontSize: 14,
    fontWeight: '900',
    letterSpacing: 2,
    textTransform: 'uppercase'
  },

  heroTitle: {
    color: '#fff',
    fontSize: 34,
    fontWeight: '900',
    marginTop: 8
  },

  heroText: {
    color: '#eee',
    fontSize: 16,
    lineHeight: 23,
    marginTop: 8
  },

  heroBtns: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 18
  },

  redBtn: {
    flex: 1,
    backgroundColor: R,
    padding: 14,
    borderRadius: 30,
    alignItems: 'center'
  },

  blackBtn: {
    flex: 1,
    backgroundColor: B,
    padding: 14,
    borderRadius: 30,
    alignItems: 'center'
  },

  search: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 10,
    gap: 10,
    marginBottom: 16
  },

  input: {
    flex: 1,
    backgroundColor: '#eee',
    borderRadius: 10,
    paddingHorizontal: 14,
    fontSize: 15
  },

  searchBtn: {
    backgroundColor: B,
    borderRadius: 10,
    paddingHorizontal: 16,
    justifyContent: 'center'
  },

  sectionTitle: {
    color: '#fff',
    fontSize: 26,
    fontWeight: '900',
    marginBottom: 12
  },

  card: {
    backgroundColor: '#fff',
    borderRadius: 24,
    marginBottom: 18,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: B
  },

  showImage: {
    height: 260,
    justifyContent: 'flex-end',
    backgroundColor: B
  },

  showImageStyle: {
    width: '100%',
    height: '100%'
  },

  showOverlay: {
    padding: 18,
    backgroundColor: 'rgba(0,0,0,0.58)'
  },

  showTitle: {
    color: '#fff',
    fontSize: 27,
    fontWeight: '900'
  },

  age: {
    alignSelf: 'flex-start',
    backgroundColor: R,
    color: '#fff',
    fontWeight: '900',
    paddingVertical: 5,
    paddingHorizontal: 12,
    borderRadius: 20,
    marginTop: 8,
    overflow: 'hidden'
  },

  body: {
    padding: 18
  },

  red: {
    color: R,
    fontWeight: '900'
  },

  muted: {
    color: '#555',
    fontWeight: '700',
    marginTop: 4
  },

  desc: {
    color: '#555',
    lineHeight: 22,
    marginTop: 10
  },

  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
    marginTop: 16
  },

  time: {
    color: B,
    fontWeight: '900',
    flex: 1
  },

  price: {
    color: R,
    fontSize: 20,
    fontWeight: '900'
  },

  btnText: {
    color: '#fff',
    fontWeight: '900'
  },

  empty: {
    color: '#fff',
    textAlign: 'center',
    marginTop: 30,
    fontWeight: '900'
  }
});