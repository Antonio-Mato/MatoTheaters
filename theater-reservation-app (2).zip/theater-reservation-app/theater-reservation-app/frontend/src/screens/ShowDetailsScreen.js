import React, { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  ImageBackground,
  Pressable,
  StyleSheet,
  Text,
  View
} from 'react-native';
import { apiRequest } from '../api/client';
import { formatDateTime, formatMoney } from '../utils/date';

const R = '#B00020';
const B = '#050505';

const SHOW_IMAGES = {
  1: require('../../assets/show-1.jpg'),
  2: require('../../assets/show-2.png'),
  3: require('../../assets/show-3.png'),
  4: require('../../assets/show-4.png')
};

export default function ShowDetailsScreen({ route, navigation }) {
  const { showId } = route.params;
  const [show, setShow] = useState(null);
  const [times, setTimes] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      const [showData, timeData] = await Promise.all([
        apiRequest(`/shows/${showId}`),
        apiRequest(`/showtimes?showId=${showId}`)
      ]);
      setShow(showData.show);
      setTimes(timeData.showtimes || []);
    } catch (e) {
      Alert.alert('Could not load show', e.message);
    } finally {
      setLoading(false);
    }
  }, [showId]);

  useEffect(() => {
    load();
  }, [load]);

  function Header() {
    return (
      <>
        <ImageBackground
          source={SHOW_IMAGES[Number(showId)]}
          resizeMode="cover"
          style={styles.hero}
        >
          <View style={styles.overlay}>
            <Pressable style={styles.backBtn} onPress={() => navigation.navigate('Home')}>
              <Text style={styles.btnText}>← Shows</Text>
            </Pressable>

            <Text style={styles.brand}>Mato's Theaters</Text>
            <Text style={styles.title}>{show.title}</Text>
            <Text style={styles.meta}>🎭 {show.theatre_name}</Text>
            <Text style={styles.meta}>📍 {show.theatre_location}</Text>
          </View>
        </ImageBackground>

        <View style={styles.infoCard}>
          <Text style={styles.desc}>{show.description}</Text>

          <View style={styles.row}>
            <Text style={styles.pill}>⏱ {show.duration_minutes} min</Text>
            <Text style={styles.pill}>Age {show.age_rating}</Text>
          </View>
        </View>

        <Text style={styles.section}>Available Showtimes</Text>
      </>
    );
  }

  function Showtime({ item }) {
    return (
      <Pressable
        style={styles.timeCard}
        onPress={() =>
          navigation.navigate('Reservation', {
            showtimeId: item.showtime_id,
            showTitle: show.title
          })
        }
      >
        <Text style={styles.timeDate}>{formatDateTime(item.starts_at)}</Text>
        <Text style={styles.small}>🏛 {item.hall_name}</Text>
        <Text style={styles.small}>
          💺 {item.available_seats}/{item.total_seats} seats available
        </Text>

        <View style={styles.bottom}>
          <Text style={styles.price}>{formatMoney(item.base_price)}</Text>
          <Text style={styles.reserve}>Reserve →</Text>
        </View>
      </Pressable>
    );
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color="#fff" size="large" />
        <Text style={styles.loading}>Loading show...</Text>
      </View>
    );
  }

  if (!show) {
    return (
      <View style={styles.center}>
        <Text style={styles.loading}>Show not found.</Text>
      </View>
    );
  }

  return (
    <View style={styles.page}>
      <FlatList
        data={times}
        keyExtractor={(x) => String(x.showtime_id)}
        renderItem={Showtime}
        ListHeaderComponent={Header}
        contentContainerStyle={styles.list}
        ListEmptyComponent={<Text style={styles.empty}>No future showtimes available.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: R
  },
  list: {
    padding: 16,
    paddingBottom: 30
  },
  center: {
    flex: 1,
    backgroundColor: R,
    justifyContent: 'center',
    alignItems: 'center'
  },
  loading: {
    color: '#fff',
    marginTop: 12,
    fontWeight: '900'
  },
  hero: {
    height: 360,
    borderRadius: 24,
    overflow: 'hidden',
    backgroundColor: B,
    marginBottom: 16
  },
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
    padding: 22,
    backgroundColor: 'rgba(0,0,0,0.55)'
  },
  backBtn: {
    position: 'absolute',
    top: 18,
    left: 18,
    backgroundColor: R,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 30
  },
  brand: {
    color: '#ffb3b3',
    fontSize: 14,
    fontWeight: '900',
    letterSpacing: 2,
    textTransform: 'uppercase'
  },
  title: {
    color: '#fff',
    fontSize: 36,
    fontWeight: '900',
    marginTop: 8
  },
  meta: {
    color: '#eee',
    fontWeight: '800',
    marginTop: 5
  },
  infoCard: {
    backgroundColor: '#fff',
    borderRadius: 22,
    padding: 18,
    marginBottom: 18,
    borderWidth: 2,
    borderColor: B
  },
  desc: {
    color: '#333',
    fontSize: 16,
    lineHeight: 23,
    fontWeight: '600'
  },
  row: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 16
  },
  pill: {
    backgroundColor: B,
    color: '#fff',
    paddingVertical: 9,
    paddingHorizontal: 14,
    borderRadius: 30,
    fontWeight: '900',
    overflow: 'hidden'
  },
  section: {
    color: '#fff',
    fontSize: 26,
    fontWeight: '900',
    marginBottom: 12
  },
  timeCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 18,
    marginBottom: 14,
    borderLeftWidth: 7,
    borderLeftColor: B
  },
  timeDate: {
    color: B,
    fontSize: 20,
    fontWeight: '900',
    marginBottom: 8
  },
  small: {
    color: '#555',
    fontWeight: '700',
    marginTop: 5
  },
  bottom: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
    alignItems: 'center'
  },
  price: {
    color: R,
    fontSize: 22,
    fontWeight: '900'
  },
  reserve: {
    color: B,
    fontWeight: '900'
  },
  btnText: {
    color: '#fff',
    fontWeight: '900'
  },
  empty: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: '900',
    marginTop: 25
  }
});
