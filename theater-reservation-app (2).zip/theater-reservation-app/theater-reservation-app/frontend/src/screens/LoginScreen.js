import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View
} from 'react-native';
import { useAuth } from '../context/AuthContext';

export default function LoginScreen({ navigation }) {
  const { login } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleLogin() {
    if (!email.trim() || !password) {
      Alert.alert('Missing details', 'Enter your email and password.');
      return;
    }

    try {
      setLoading(true);
      await login(email.trim(), password);
    } catch (error) {
      Alert.alert('Login failed', error.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.page}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <View style={styles.hero}>
          <Text style={styles.brand}>Mato's Theaters</Text>
          <Text style={styles.heroTitle}>Welcome back</Text>
          <Text style={styles.heroText}>
            Sign in to book shows, reserve seats, and manage your theatre tickets.
          </Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.title}>Sign in</Text>

          <TextInput
            style={styles.input}
            placeholder="Email address"
            placeholderTextColor="#777"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
          />

          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor="#777"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          <Pressable style={styles.mainBtn} onPress={handleLogin} disabled={loading}>
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.btnText}>Sign in</Text>
            )}
          </Pressable>

          <Pressable onPress={() => navigation.navigate('Register')}>
            <Text style={styles.link}>Create a new account</Text>
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const R = '#B00020';
const B = '#050505';

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: R
  },
  scroll: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 22
  },
  hero: {
    backgroundColor: B,
    borderRadius: 24,
    padding: 24,
    marginBottom: 18
  },
  brand: {
    color: '#ffb3b3',
    fontSize: 15,
    fontWeight: '900',
    letterSpacing: 2,
    textTransform: 'uppercase',
    marginBottom: 14
  },
  heroTitle: {
    color: '#fff',
    fontSize: 34,
    fontWeight: '900',
    marginBottom: 8
  },
  heroText: {
    color: '#ddd',
    fontSize: 16,
    lineHeight: 24
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 24,
    padding: 24,
    elevation: 8
  },
  title: {
    color: B,
    fontSize: 30,
    fontWeight: '900',
    marginBottom: 22,
    textAlign: 'center'
  },
  input: {
    height: 58,
    backgroundColor: '#eee',
    borderRadius: 14,
    paddingHorizontal: 18,
    fontSize: 16,
    marginBottom: 14,
    color: B
  },
  mainBtn: {
    height: 58,
    backgroundColor: B,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 6
  },
  btnText: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '900'
  },
  link: {
    color: R,
    fontSize: 16,
    fontWeight: '800',
    textAlign: 'center',
    marginTop: 20
  }
});