const bcrypt = require('bcryptjs');
const { pool } = require('../config/db');
const { signToken } = require('../utils/token');
const { isValidEmail, isStrongEnoughPassword } = require('../utils/validation');

async function register({ name, email, password }) {
  if (!name || typeof name !== 'string' || name.trim().length < 2) {
    const error = new Error('Name must contain at least 2 characters');
    error.statusCode = 400;
    throw error;
  }

  if (!isValidEmail(email)) {
    const error = new Error('A valid email address is required');
    error.statusCode = 400;
    throw error;
  }

  if (!isStrongEnoughPassword(password)) {
    const error = new Error('Password must contain at least 8 characters');
    error.statusCode = 400;
    throw error;
  }

  const normalizedEmail = email.trim().toLowerCase();
  const [existingUsers] = await pool.execute('SELECT user_id FROM users WHERE email = ?', [normalizedEmail]);

  if (existingUsers.length > 0) {
    const error = new Error('Email is already registered');
    error.statusCode = 409;
    throw error;
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const [result] = await pool.execute(
    'INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)',
    [name.trim(), normalizedEmail, passwordHash]
  );

  const user = {
    user_id: result.insertId,
    name: name.trim(),
    email: normalizedEmail
  };

  return {
    user,
    token: signToken(user)
  };
}

async function login({ email, password }) {
  if (!isValidEmail(email) || typeof password !== 'string') {
    const error = new Error('Invalid email or password');
    error.statusCode = 400;
    throw error;
  }

  const normalizedEmail = email.trim().toLowerCase();
  const [rows] = await pool.execute(
    'SELECT user_id, name, email, password_hash FROM users WHERE email = ?',
    [normalizedEmail]
  );

  if (rows.length === 0) {
    const error = new Error('Invalid email or password');
    error.statusCode = 401;
    throw error;
  }

  const user = rows[0];
  const passwordMatches = await bcrypt.compare(password, user.password_hash);

  if (!passwordMatches) {
    const error = new Error('Invalid email or password');
    error.statusCode = 401;
    throw error;
  }

  const safeUser = {
    user_id: user.user_id,
    name: user.name,
    email: user.email
  };

  return {
    user: safeUser,
    token: signToken(safeUser)
  };
}

module.exports = {
  register,
  login
};
