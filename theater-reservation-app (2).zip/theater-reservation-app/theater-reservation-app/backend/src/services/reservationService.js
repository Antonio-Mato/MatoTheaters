const { pool } = require('../config/db');
const { toPositiveInteger, toPositiveIntegerArray } = require('../utils/validation');

function makeHttpError(message, statusCode) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

async function loadAndValidateShowtime(connection, showtimeId) {
  const [showtimeRows] = await connection.execute(
    `
      SELECT
        st.showtime_id,
        st.show_id,
        st.hall_id,
        st.starts_at,
        st.base_price,
        h.name AS hall_name,
        s.title AS show_title
      FROM showtimes st
      INNER JOIN halls h ON h.hall_id = st.hall_id
      INNER JOIN shows s ON s.show_id = st.show_id
      WHERE st.showtime_id = ? AND st.starts_at > NOW()
      FOR UPDATE
    `,
    [showtimeId]
  );

  if (showtimeRows.length === 0) {
    throw makeHttpError('Showtime not found or it is no longer bookable', 404);
  }

  return showtimeRows[0];
}

async function validateSeatsForShowtime(connection, showtime, seatIds) {
  const placeholders = seatIds.map(() => '?').join(', ');
  const [seatRows] = await connection.execute(
    `
      SELECT seat_id, row_label, seat_number, category, price_modifier
      FROM seats
      WHERE hall_id = ? AND seat_id IN (${placeholders})
      ORDER BY row_label ASC, seat_number ASC
    `,
    [showtime.hall_id, ...seatIds]
  );

  if (seatRows.length !== seatIds.length) {
    throw makeHttpError('One or more selected seats do not belong to this hall', 400);
  }

  const [reservedRows] = await connection.execute(
    `
      SELECT seat_id
      FROM reservation_seats
      WHERE showtime_id = ? AND seat_id IN (${placeholders})
      FOR UPDATE
    `,
    [showtime.showtime_id, ...seatIds]
  );

  if (reservedRows.length > 0) {
    const reservedSeatIds = reservedRows.map((seat) => seat.seat_id).join(', ');
    throw makeHttpError(`Seats already reserved: ${reservedSeatIds}`, 409);
  }

  return seatRows;
}

function calculateTotalPrice(showtime, seats) {
  return seats.reduce((total, seat) => total + Number(showtime.base_price) + Number(seat.price_modifier), 0);
}

async function createReservation(userId, payload) {
  const showtimeId = toPositiveInteger(payload.showtimeId);
  const seatIds = toPositiveIntegerArray(payload.seatIds);

  if (!showtimeId || !seatIds || seatIds.length === 0) {
    throw makeHttpError('showtimeId and seatIds are required', 400);
  }

  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const showtime = await loadAndValidateShowtime(connection, showtimeId);
    const seats = await validateSeatsForShowtime(connection, showtime, seatIds);
    const totalPrice = calculateTotalPrice(showtime, seats);

    const [reservationResult] = await connection.execute(
      `
        INSERT INTO reservations (user_id, showtime_id, total_price, status)
        VALUES (?, ?, ?, 'CONFIRMED')
      `,
      [userId, showtimeId, totalPrice]
    );

    const reservationId = reservationResult.insertId;

    for (const seat of seats) {
      const pricePaid = Number(showtime.base_price) + Number(seat.price_modifier);
      await connection.execute(
        `
          INSERT INTO reservation_seats (reservation_id, showtime_id, seat_id, price_paid)
          VALUES (?, ?, ?, ?)
        `,
        [reservationId, showtimeId, seat.seat_id, pricePaid]
      );
    }

    await connection.commit();

    return getReservationById(userId, reservationId);
  } catch (error) {
    await connection.rollback();

    if (error && error.code === 'ER_DUP_ENTRY') {
      throw makeHttpError('At least one selected seat was reserved by another user. Please refresh availability.', 409);
    }

    throw error;
  } finally {
    connection.release();
  }
}

async function updateReservation(userId, reservationId, payload) {
  const parsedReservationId = toPositiveInteger(reservationId);
  const newShowtimeId = toPositiveInteger(payload.showtimeId);
  const seatIds = toPositiveIntegerArray(payload.seatIds);

  if (!parsedReservationId || !newShowtimeId || !seatIds || seatIds.length === 0) {
    throw makeHttpError('reservationId, showtimeId and seatIds are required', 400);
  }

  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [reservationRows] = await connection.execute(
      `
        SELECT r.reservation_id, r.user_id, r.status, st.starts_at
        FROM reservations r
        INNER JOIN showtimes st ON st.showtime_id = r.showtime_id
        WHERE r.reservation_id = ? AND r.user_id = ?
        FOR UPDATE
      `,
      [parsedReservationId, userId]
    );

    if (reservationRows.length === 0) {
      throw makeHttpError('Reservation not found', 404);
    }

    if (reservationRows[0].status !== 'CONFIRMED') {
      throw makeHttpError('Only confirmed reservations can be modified', 400);
    }

    if (new Date(reservationRows[0].starts_at).getTime() <= Date.now()) {
      throw makeHttpError('Past reservations cannot be modified', 400);
    }

    await connection.execute(
      'DELETE FROM reservation_seats WHERE reservation_id = ?',
      [parsedReservationId]
    );

    const showtime = await loadAndValidateShowtime(connection, newShowtimeId);
    const seats = await validateSeatsForShowtime(connection, showtime, seatIds);
    const totalPrice = calculateTotalPrice(showtime, seats);

    await connection.execute(
      `
        UPDATE reservations
        SET showtime_id = ?, total_price = ?, updated_at = NOW()
        WHERE reservation_id = ? AND user_id = ?
      `,
      [newShowtimeId, totalPrice, parsedReservationId, userId]
    );

    for (const seat of seats) {
      const pricePaid = Number(showtime.base_price) + Number(seat.price_modifier);
      await connection.execute(
        `
          INSERT INTO reservation_seats (reservation_id, showtime_id, seat_id, price_paid)
          VALUES (?, ?, ?, ?)
        `,
        [parsedReservationId, newShowtimeId, seat.seat_id, pricePaid]
      );
    }

    await connection.commit();

    return getReservationById(userId, parsedReservationId);
  } catch (error) {
    await connection.rollback();

    if (error && error.code === 'ER_DUP_ENTRY') {
      throw makeHttpError('At least one selected seat was reserved by another user. Please refresh availability.', 409);
    }

    throw error;
  } finally {
    connection.release();
  }
}

async function cancelReservation(userId, reservationId) {
  const parsedReservationId = toPositiveInteger(reservationId);

  if (!parsedReservationId) {
    throw makeHttpError('Valid reservation id is required', 400);
  }

  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [reservationRows] = await connection.execute(
      `
        SELECT r.reservation_id, r.status, st.starts_at
        FROM reservations r
        INNER JOIN showtimes st ON st.showtime_id = r.showtime_id
        WHERE r.reservation_id = ? AND r.user_id = ?
        FOR UPDATE
      `,
      [parsedReservationId, userId]
    );

    if (reservationRows.length === 0) {
      throw makeHttpError('Reservation not found', 404);
    }

    if (reservationRows[0].status !== 'CONFIRMED') {
      throw makeHttpError('Reservation is already cancelled', 400);
    }

    if (new Date(reservationRows[0].starts_at).getTime() <= Date.now()) {
      throw makeHttpError('Past reservations cannot be cancelled', 400);
    }

    await connection.execute(
      'DELETE FROM reservation_seats WHERE reservation_id = ?',
      [parsedReservationId]
    );

    await connection.execute(
      `
        UPDATE reservations
        SET status = 'CANCELLED', updated_at = NOW()
        WHERE reservation_id = ? AND user_id = ?
      `,
      [parsedReservationId, userId]
    );

    await connection.commit();

    return { reservation_id: parsedReservationId, status: 'CANCELLED' };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function getReservationById(userId, reservationId) {
  const [rows] = await pool.execute(
    `
      SELECT
        r.reservation_id,
        r.status,
        r.total_price,
        r.created_at,
        r.updated_at,
        st.showtime_id,
        st.starts_at,
        st.ends_at,
        s.show_id,
        s.title AS show_title,
        t.name AS theatre_name,
        t.location AS theatre_location,
        h.name AS hall_name,
        GROUP_CONCAT(CONCAT(se.row_label, se.seat_number) ORDER BY se.row_label, se.seat_number SEPARATOR ', ') AS seats,
        GROUP_CONCAT(se.seat_id ORDER BY se.row_label, se.seat_number SEPARATOR ',') AS seat_ids
      FROM reservations r
      INNER JOIN showtimes st ON st.showtime_id = r.showtime_id
      INNER JOIN shows s ON s.show_id = st.show_id
      INNER JOIN theatres t ON t.theatre_id = s.theatre_id
      INNER JOIN halls h ON h.hall_id = st.hall_id
      LEFT JOIN reservation_seats rs ON rs.reservation_id = r.reservation_id
      LEFT JOIN seats se ON se.seat_id = rs.seat_id
      WHERE r.user_id = ? AND r.reservation_id = ?
      GROUP BY r.reservation_id
    `,
    [userId, reservationId]
  );

  if (rows.length === 0) {
    throw makeHttpError('Reservation not found', 404);
  }

  return rows[0];
}

async function getUserReservations(userId) {
  const [rows] = await pool.execute(
    `
      SELECT
        r.reservation_id,
        r.status,
        r.total_price,
        r.created_at,
        r.updated_at,
        st.showtime_id,
        st.starts_at,
        st.ends_at,
        s.show_id,
        s.title AS show_title,
        t.name AS theatre_name,
        t.location AS theatre_location,
        h.name AS hall_name,
        GROUP_CONCAT(CONCAT(se.row_label, se.seat_number) ORDER BY se.row_label, se.seat_number SEPARATOR ', ') AS seats,
        COUNT(se.seat_id) AS seat_count
      FROM reservations r
      INNER JOIN showtimes st ON st.showtime_id = r.showtime_id
      INNER JOIN shows s ON s.show_id = st.show_id
      INNER JOIN theatres t ON t.theatre_id = s.theatre_id
      INNER JOIN halls h ON h.hall_id = st.hall_id
      LEFT JOIN reservation_seats rs ON rs.reservation_id = r.reservation_id
      LEFT JOIN seats se ON se.seat_id = rs.seat_id
      WHERE r.user_id = ?
      GROUP BY r.reservation_id
      ORDER BY st.starts_at DESC
    `,
    [userId]
  );

  return rows;
}

module.exports = {
  createReservation,
  updateReservation,
  cancelReservation,
  getUserReservations,
  getReservationById
};
