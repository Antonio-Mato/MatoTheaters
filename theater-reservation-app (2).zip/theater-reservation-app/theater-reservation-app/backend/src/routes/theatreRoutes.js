const express = require('express');
const theatreController = require('../controllers/theatreController');

const router = express.Router();

router.get('/theatres', theatreController.getTheatres);
router.get('/theatres/:id', theatreController.getTheatreById);

module.exports = router;
