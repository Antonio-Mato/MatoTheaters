const express = require('express');
const showController = require('../controllers/showController');

const router = express.Router();

router.get('/shows', showController.getShows);
router.get('/shows/:id', showController.getShowById);
router.get('/showtimes', showController.getShowtimes);
router.get('/seats', showController.getSeats);

module.exports = router;
