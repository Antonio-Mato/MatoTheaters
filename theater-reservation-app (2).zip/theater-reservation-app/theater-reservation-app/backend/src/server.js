require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const { testConnection } = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const theatreRoutes = require('./routes/theatreRoutes');
const showRoutes = require('./routes/showRoutes');
const reservationRoutes = require('./routes/reservationRoutes');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const app = express();
const port = Number(process.env.PORT || 3000);

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 300,
  standardHeaders: true,
  legacyHeaders: false
}));

app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'theatre-reservation-api',
    timestamp: new Date().toISOString()
  });
});

app.use('/api', authRoutes);
app.use('/api', theatreRoutes);
app.use('/api', showRoutes);
app.use('/api', reservationRoutes);

app.use(notFound);
app.use(errorHandler);

async function start() {
  try {
    await testConnection();
    app.listen(port, '0.0.0.0', () => {
      console.log(`API running on http://localhost:${port}/api`);
    });
  } catch (error) {
    console.error('Failed to start server:', error.message);
    process.exit(1);
  }
}

start();
