function isValidEmail(email) {
  return typeof email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isStrongEnoughPassword(password) {
  return typeof password === 'string' && password.length >= 8;
}

function toPositiveInteger(value) {
  const number = Number(value);
  if (!Number.isInteger(number) || number <= 0) return null;
  return number;
}

function toPositiveIntegerArray(value) {
  if (!Array.isArray(value)) return null;
  const parsed = value.map(toPositiveInteger);
  if (parsed.some((item) => item === null)) return null;
  return [...new Set(parsed)];
}

module.exports = {
  isValidEmail,
  isStrongEnoughPassword,
  toPositiveInteger,
  toPositiveIntegerArray
};
