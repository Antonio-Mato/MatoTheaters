const jwt = require('jsonwebtoken');

function signToken(user) {
  return jwt.sign(
    {
      userId: user.user_id,
      email: user.email
    },
    process.env.JWT_SECRET || 'development_secret',
    {
      expiresIn: process.env.JWT_EXPIRES_IN || '2h'
    }
  );
}

module.exports = {
  signToken
};
