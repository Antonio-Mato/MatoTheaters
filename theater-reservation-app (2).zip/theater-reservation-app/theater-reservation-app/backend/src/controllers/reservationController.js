const reservationService = require('../services/reservationService');

async function createReservation(req, res, next) {
  try {
    const reservation = await reservationService.createReservation(req.user.user_id, req.body);
    res.status(201).json({ reservation });
  } catch (error) {
    next(error);
  }
}

async function updateReservation(req, res, next) {
  try {
    const reservation = await reservationService.updateReservation(
      req.user.user_id,
      req.params.id,
      req.body
    );
    res.json({ reservation });
  } catch (error) {
    next(error);
  }
}

async function cancelReservation(req, res, next) {
  try {
    const result = await reservationService.cancelReservation(req.user.user_id, req.params.id);
    res.json({ reservation: result });
  } catch (error) {
    next(error);
  }
}

async function getMyReservations(req, res, next) {
  try {
    const reservations = await reservationService.getUserReservations(req.user.user_id);
    res.json({ reservations });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  createReservation,
  updateReservation,
  cancelReservation,
  getMyReservations
};
