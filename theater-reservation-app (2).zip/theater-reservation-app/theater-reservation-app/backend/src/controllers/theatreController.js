const { pool } = require('../config/db');

async function getTheatres(req, res, next) {
  try {
    const search = req.query.search ? `%${req.query.search}%` : null;
    const params = [];

    let sql = `
      SELECT
        t.theatre_id,
        t.name,
        t.location,
        t.description,
        COUNT(DISTINCT h.hall_id) AS hall_count,
        COUNT(DISTINCT s.show_id) AS show_count
      FROM theatres t
      LEFT JOIN halls h ON h.theatre_id = t.theatre_id
      LEFT JOIN shows s ON s.theatre_id = t.theatre_id
    `;

    if (search) {
      sql += ' WHERE t.name LIKE ? OR t.location LIKE ? ';
      params.push(search, search);
    }

    sql += ' GROUP BY t.theatre_id ORDER BY t.name ASC';

    const [rows] = await pool.execute(sql, params);
    res.json({ theatres: rows });
  } catch (error) {
    next(error);
  }
}

async function getTheatreById(req, res, next) {
  try {
    const [rows] = await pool.execute(
      `
        SELECT theatre_id, name, location, description
        FROM theatres
        WHERE theatre_id = ?
      `,
      [req.params.id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Theatre not found' });
    }

    res.json({ theatre: rows[0] });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getTheatres,
  getTheatreById
};
