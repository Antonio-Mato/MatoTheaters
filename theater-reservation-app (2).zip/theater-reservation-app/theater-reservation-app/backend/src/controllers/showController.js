const { pool } = require('../config/db');

async function getShows(req, res, next) {
  try {
    const { theatreId, title, date, location, q } = req.query;
    const where = [];
    const params = [];

    if (theatreId) {
      where.push('s.theatre_id = ?');
      params.push(theatreId);
    }

    if (title) {
      where.push('s.title LIKE ?');
      params.push(`%${title}%`);
    }

    if (location) {
      where.push('t.location LIKE ?');
      params.push(`%${location}%`);
    }

    if (q) {
      where.push('(s.title LIKE ? OR t.name LIKE ? OR t.location LIKE ?)');
      params.push(`%${q}%`, `%${q}%`, `%${q}%`);
    }

    if (date) {
      where.push('DATE(st.starts_at) = ?');
      params.push(date);
    }

    let sql = `
      SELECT
        s.show_id,
        s.theatre_id,
        s.title,
        s.description,
        s.duration_minutes,
        s.age_rating,
        t.name AS theatre_name,
        t.location AS theatre_location,
        MIN(st.starts_at) AS next_showtime,
        MIN(st.base_price) AS starting_price
      FROM shows s
      INNER JOIN theatres t ON t.theatre_id = s.theatre_id
      LEFT JOIN showtimes st ON st.show_id = s.show_id AND st.starts_at > NOW()
    `;

    if (where.length > 0) {
      sql += ` WHERE ${where.join(' AND ')}`;
    }

sql += `
  GROUP BY
    s.show_id,
    s.theatre_id,
    s.title,
    s.description,
    s.duration_minutes,
    s.age_rating,
    t.name,
    t.location
  ORDER BY MIN(st.starts_at) IS NULL ASC, MIN(st.starts_at) ASC, s.title ASC
`;

    const [rows] = await pool.execute(sql, params);
    res.json({ shows: rows });
  } catch (error) {
    next(error);
  }
}

async function getShowById(req, res, next) {
  try {
    const [rows] = await pool.execute(
      `
        SELECT
          s.show_id,
          s.theatre_id,
          s.title,
          s.description,
          s.duration_minutes,
          s.age_rating,
          t.name AS theatre_name,
          t.location AS theatre_location,
          t.description AS theatre_description
        FROM shows s
        INNER JOIN theatres t ON t.theatre_id = s.theatre_id
        WHERE s.show_id = ?
      `,
      [req.params.id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Show not found' });
    }

    res.json({ show: rows[0] });
  } catch (error) {
    next(error);
  }
}

async function getShowtimes(req, res, next) {
  try {
    const { showId } = req.query;
    const params = [];
    let where = 'WHERE st.starts_at > NOW()';

    if (showId) {
      where += ' AND st.show_id = ?';
      params.push(showId);
    }

    const [rows] = await pool.execute(
      `
        SELECT
          st.showtime_id,
          st.show_id,
          st.hall_id,
          st.starts_at,
          st.ends_at,
          st.base_price,
          h.name AS hall_name,
          h.capacity,
          s.title AS show_title,
          t.name AS theatre_name,
          t.location AS theatre_location,
          COUNT(se.seat_id) AS total_seats,
          COUNT(se.seat_id) - COUNT(rs.seat_id) AS available_seats
        FROM showtimes st
        INNER JOIN halls h ON h.hall_id = st.hall_id
        INNER JOIN shows s ON s.show_id = st.show_id
        INNER JOIN theatres t ON t.theatre_id = s.theatre_id
        INNER JOIN seats se ON se.hall_id = h.hall_id
        LEFT JOIN reservation_seats rs ON rs.showtime_id = st.showtime_id AND rs.seat_id = se.seat_id
        ${where}
        GROUP BY st.showtime_id
        ORDER BY st.starts_at ASC
      `,
      params
    );

    res.json({ showtimes: rows });
  } catch (error) {
    next(error);
  }
}

async function getSeats(req, res, next) {
  try {
    const { showtimeId } = req.query;

    if (!showtimeId) {
      return res.status(400).json({ message: 'showtimeId query parameter is required' });
    }

    const [showtimeRows] = await pool.execute(
      `
        SELECT
          st.showtime_id,
          st.base_price,
          h.hall_id,
          h.name AS hall_name,
          s.title AS show_title
        FROM showtimes st
        INNER JOIN halls h ON h.hall_id = st.hall_id
        INNER JOIN shows s ON s.show_id = st.show_id
        WHERE st.showtime_id = ?
      `,
      [showtimeId]
    );

    if (showtimeRows.length === 0) {
      return res.status(404).json({ message: 'Showtime not found' });
    }

    const showtime = showtimeRows[0];
    const [seats] = await pool.execute(
      `
        SELECT
          se.seat_id,
          se.row_label,
          se.seat_number,
          se.category,
          ROUND(? + se.price_modifier, 2) AS final_price,
          CASE WHEN rs.reservation_seat_id IS NULL THEN 1 ELSE 0 END AS is_available
        FROM seats se
        LEFT JOIN reservation_seats rs ON rs.showtime_id = ? AND rs.seat_id = se.seat_id
        WHERE se.hall_id = ?
        ORDER BY se.row_label ASC, se.seat_number ASC
      `,
      [showtime.base_price, showtimeId, showtime.hall_id]
    );

    res.json({ showtime, seats });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getShows,
  getShowById,
  getShowtimes,
  getSeats
};
