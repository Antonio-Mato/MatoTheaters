const jwt = require('jsonwebtoken');
const { pool } = require('../config/db');

async function authenticate(req, res, next) {
  try {
    const header = req.headers.authorization;

    if (!header || !header.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'Authentication token is missing' });
    }

    const token = header.replace('Bearer ', '').trim();
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'development_secret');

    const [rows] = await pool.execute(
      'SELECT user_id, name, email, created_at FROM users WHERE user_id = ?',
      [payload.userId]
    );

    if (rows.length === 0) {
      return res.status(401).json({ message: 'User no longer exists' });
    }

    req.user = rows[0];
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid or expired authentication token' });
  }
}

module.exports = {
  authenticate
};
