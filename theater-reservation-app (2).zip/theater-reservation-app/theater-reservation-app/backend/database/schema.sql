CREATE DATABASE IF NOT EXISTS theater_reservation_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE theater_reservation_db;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS reservation_seats;
DROP TABLE IF EXISTS reservations;
DROP TABLE IF EXISTS showtimes;
DROP TABLE IF EXISTS seats;
DROP TABLE IF EXISTS shows;
DROP TABLE IF EXISTS halls;
DROP TABLE IF EXISTS theatres;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE theatres (
  theatre_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  location VARCHAR(160) NOT NULL,
  description TEXT
) ENGINE=InnoDB;

CREATE TABLE halls (
  hall_id INT AUTO_INCREMENT PRIMARY KEY,
  theatre_id INT NOT NULL,
  name VARCHAR(120) NOT NULL,
  capacity INT NOT NULL,
  CONSTRAINT fk_halls_theatre
    FOREIGN KEY (theatre_id) REFERENCES theatres(theatre_id)
    ON DELETE CASCADE,
  INDEX idx_halls_theatre_id (theatre_id)
) ENGINE=InnoDB;

CREATE TABLE shows (
  show_id INT AUTO_INCREMENT PRIMARY KEY,
  theatre_id INT NOT NULL,
  title VARCHAR(180) NOT NULL,
  description TEXT,
  duration_minutes INT NOT NULL,
  age_rating VARCHAR(20) NOT NULL DEFAULT 'All',
  CONSTRAINT fk_shows_theatre
    FOREIGN KEY (theatre_id) REFERENCES theatres(theatre_id)
    ON DELETE CASCADE,
  INDEX idx_shows_theatre_id (theatre_id),
  INDEX idx_shows_title (title)
) ENGINE=InnoDB;

CREATE TABLE seats (
  seat_id INT AUTO_INCREMENT PRIMARY KEY,
  hall_id INT NOT NULL,
  row_label VARCHAR(5) NOT NULL,
  seat_number INT NOT NULL,
  category ENUM('VIP', 'STANDARD', 'ECONOMY') NOT NULL DEFAULT 'STANDARD',
  price_modifier DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  CONSTRAINT fk_seats_hall
    FOREIGN KEY (hall_id) REFERENCES halls(hall_id)
    ON DELETE CASCADE,
  UNIQUE KEY uq_seat_position (hall_id, row_label, seat_number),
  INDEX idx_seats_hall_id (hall_id)
) ENGINE=InnoDB;

CREATE TABLE showtimes (
  showtime_id INT AUTO_INCREMENT PRIMARY KEY,
  show_id INT NOT NULL,
  hall_id INT NOT NULL,
  starts_at DATETIME NOT NULL,
  ends_at DATETIME NOT NULL,
  base_price DECIMAL(8,2) NOT NULL,
  CONSTRAINT fk_showtimes_show
    FOREIGN KEY (show_id) REFERENCES shows(show_id)
    ON DELETE CASCADE,
  CONSTRAINT fk_showtimes_hall
    FOREIGN KEY (hall_id) REFERENCES halls(hall_id)
    ON DELETE RESTRICT,
  INDEX idx_showtimes_show_id (show_id),
  INDEX idx_showtimes_hall_id (hall_id),
  INDEX idx_showtimes_starts_at (starts_at)
) ENGINE=InnoDB;

CREATE TABLE reservations (
  reservation_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  showtime_id INT NOT NULL,
  total_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  status ENUM('CONFIRMED', 'CANCELLED') NOT NULL DEFAULT 'CONFIRMED',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_reservations_user
    FOREIGN KEY (user_id) REFERENCES users(user_id)
    ON DELETE CASCADE,
  CONSTRAINT fk_reservations_showtime
    FOREIGN KEY (showtime_id) REFERENCES showtimes(showtime_id)
    ON DELETE RESTRICT,
  INDEX idx_reservations_user_id (user_id),
  INDEX idx_reservations_showtime_id (showtime_id),
  INDEX idx_reservations_status (status)
) ENGINE=InnoDB;

CREATE TABLE reservation_seats (
  reservation_seat_id INT AUTO_INCREMENT PRIMARY KEY,
  reservation_id INT NOT NULL,
  showtime_id INT NOT NULL,
  seat_id INT NOT NULL,
  price_paid DECIMAL(8,2) NOT NULL,
  CONSTRAINT fk_reservation_seats_reservation
    FOREIGN KEY (reservation_id) REFERENCES reservations(reservation_id)
    ON DELETE CASCADE,
  CONSTRAINT fk_reservation_seats_showtime
    FOREIGN KEY (showtime_id) REFERENCES showtimes(showtime_id)
    ON DELETE RESTRICT,
  CONSTRAINT fk_reservation_seats_seat
    FOREIGN KEY (seat_id) REFERENCES seats(seat_id)
    ON DELETE RESTRICT,
  UNIQUE KEY uq_reserved_seat_per_showtime (showtime_id, seat_id),
  INDEX idx_reservation_seats_reservation_id (reservation_id),
  INDEX idx_reservation_seats_seat_id (seat_id)
) ENGINE=InnoDB;
