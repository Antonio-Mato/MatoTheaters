start xampp mysql and apache
cd backend 
npm run dev
cd frontend σε διαφροετικο terminal
npx expo start -c
κατεβασμα ολα τα απαραιτητα αρχεια 
